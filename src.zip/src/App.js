import React from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Post from './components/Post';
import ArtistsSidebar from './components/ArtistsSidebar';
import Footer from './components/Footer';

const App = () => {
  return (
    <div className="min-h-screen flex container-fluid flex-col">
      <Header />
      <div className="flex bg-gray-100 flex-1">
        <Sidebar />
        <Post />
        <ArtistsSidebar />
      </div>
      {/* <Footer /> */}
    </div>
  );
};

export default App;
