export const artists = [
    {
      name: "Thomas Edward",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.zEpuzxJg3qgUeAQCZoZWjQHaH6?w=174&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th?q=Acrylic+Figure+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247"
    },
    {
      name: "Chris Doe",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.p0aui5zUigNcx_7RWGYq1QHaFc?w=221&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.jBLQhu8cbL3cZylWoOdQHQHaF6?w=218&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Emilie Jones",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.cfTAPkZ3mdTbTxS7MQoqWQHaE8?w=282&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hgKISTmjc413JhnlmgmdswHaHl?w=149&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Jessica Williams",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.2Yyfbg-YORJ0oWsPUrTw3wHaF9?w=247&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hv51w61Dbwd7foKmFqdljQHaH9?w=185&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    }, {
      name: "Thomas Edward",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.zEpuzxJg3qgUeAQCZoZWjQHaH6?w=174&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th?q=Acrylic+Figure+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247"
    },
    {
      name: "Chris Doe",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.p0aui5zUigNcx_7RWGYq1QHaFc?w=221&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.jBLQhu8cbL3cZylWoOdQHQHaF6?w=218&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Emilie Jones",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.cfTAPkZ3mdTbTxS7MQoqWQHaE8?w=282&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hgKISTmjc413JhnlmgmdswHaHl?w=149&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Jessica Williams",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.2Yyfbg-YORJ0oWsPUrTw3wHaF9?w=247&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hv51w61Dbwd7foKmFqdljQHaH9?w=185&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    }, {
      name: "Thomas Edward",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.zEpuzxJg3qgUeAQCZoZWjQHaH6?w=174&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th?q=Acrylic+Figure+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247"
    },
    {
      name: "Chris Doe",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.p0aui5zUigNcx_7RWGYq1QHaFc?w=221&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.jBLQhu8cbL3cZylWoOdQHQHaF6?w=218&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Emilie Jones",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.cfTAPkZ3mdTbTxS7MQoqWQHaE8?w=282&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hgKISTmjc413JhnlmgmdswHaHl?w=149&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Jessica Williams",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.2Yyfbg-YORJ0oWsPUrTw3wHaF9?w=247&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hv51w61Dbwd7foKmFqdljQHaH9?w=185&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    }, {
      name: "Thomas Edward",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.zEpuzxJg3qgUeAQCZoZWjQHaH6?w=174&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th?q=Acrylic+Figure+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247"
    },
    {
      name: "Chris Doe",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.p0aui5zUigNcx_7RWGYq1QHaFc?w=221&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.jBLQhu8cbL3cZylWoOdQHQHaF6?w=218&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Emilie Jones",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.cfTAPkZ3mdTbTxS7MQoqWQHaE8?w=282&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hgKISTmjc413JhnlmgmdswHaHl?w=149&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Jessica Williams",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.2Yyfbg-YORJ0oWsPUrTw3wHaF9?w=247&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hv51w61Dbwd7foKmFqdljQHaH9?w=185&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    }, {
      name: "Thomas Edward",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.zEpuzxJg3qgUeAQCZoZWjQHaH6?w=174&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th?q=Acrylic+Figure+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247"
    },
    {
      name: "Chris Doe",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.p0aui5zUigNcx_7RWGYq1QHaFc?w=221&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.jBLQhu8cbL3cZylWoOdQHQHaF6?w=218&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Emilie Jones",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.cfTAPkZ3mdTbTxS7MQoqWQHaE8?w=282&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hgKISTmjc413JhnlmgmdswHaHl?w=149&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    },
    {
      name: "Jessica Williams",
      username: "@thewildwithyou",
      profileImage: "https://th.bing.com/th/id/OIP.2Yyfbg-YORJ0oWsPUrTw3wHaF9?w=247&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7",
      squareImage: "https://th.bing.com/th/id/OIP.hv51w61Dbwd7foKmFqdljQHaH9?w=185&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"
    }
    // Add more artists as needed
  ];