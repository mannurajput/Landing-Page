// src/components/Sidebar.js
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faBell, faStore, faCommentDots, faWallet, faStream, faUser, faCog, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

const Sidebar = () => {
  return (
    <div className="flex justify-center pt-9 items-center bg-gray-100 h-full p-4">
      <div className="w-[260px] h-[707px] p-4 bg-white rounded-md shadow-md">
        <nav className="space-y-4">
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faHome} className="mr-2"/> Home
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faBell} className="mr-2"/> Notifications
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faStore} className="mr-2"/> Shop
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faCommentDots} className="mr-2"/> Conversation
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faWallet} className="mr-2"/> Wallet
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faStream} className="mr-2"/> Subscription
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faUser} className="mr-2"/> My Profile
          </a>
          <a href="/" className="flex items-center py-2 px-4 rounded hover:bg-gray-200">
            <FontAwesomeIcon icon={faCog} className="mr-2"/> Settings
          </a>
        </nav>
        <a href="/" className="flex items-center py-2 mt-[100px] px-4 rounded text-cyan-400">
          <FontAwesomeIcon icon={faSignOutAlt} className="mr-2"/> Log out
        </a>
       
      </div> 
    </div>
  );
};

export default Sidebar;
