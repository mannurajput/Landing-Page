// Header.js
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faFilter } from '@fortawesome/free-solid-svg-icons';

const Header = () => {
  return (
    <div className="flex items-center justify-between p-4 bg-gray-100">
      <div className="flex items-center bg-white w-64 h-20 justify-center rounded-md shadow">
        <div className="text-2xl pr-20 font-bold">LOGO</div>
      </div>
      <div className="relative flex items-center bg-white w-[620px] h-20 mx-4 rounded-md shadow">
        <FontAwesomeIcon icon={faSearch} className="absolute left-4 text-gray-400" />
        <input 
          type="text" 
          placeholder="Search here..." 
          className="w-full h-full p-4 pl-14 text-gray-700 bg-white border-none rounded-md focus:outline-none"
        />
       <p className='absolute right-2'> Filters</p>
        <FontAwesomeIcon icon={faFilter} className="absolute right-[55px] text-gray-400" />
      </div>
      <button className="w-64 h-20 text-white bg-teal-500 rounded-md hover:bg-teal-600 focus:outline-none shadow">
        Become a Seller
      </button>
    </div>
  );
};

export default Header;
