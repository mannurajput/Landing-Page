import React from 'react';
import { artists } from './ArtisData';


const ArtistsSidebar = () => {
  return (
    <aside className="w-1/4 p-4 bg-grey-100 h-full overflow-y-auto" style={{ paddingLeft: '16px', paddingRight: '16px' }}>
      <div className='flex -between'> <p className="text-[16px] font-bold mb-4">Artists</p>
      <p className="text-[16px] text-gray-400 font-bold ml-4 mb-4">Photographers</p>
      
      </div>
     
      
      <div className="space-y-4" style={{ maxHeight: '414px' }}>
        {artists.map((artist, index) => (
          <div key={index} className="relative" style={{ width: '244px', height: '126px' }}>
            <img src={artist.squareImage} alt="Square" className="w-full h-full object-cover rounded-lg mb-4" />
            <div className="absolute bottom-2 left-2">
              <div className="relative">
                <img src={artist.profileImage} alt="Artist" className="h-12 w-12 object-cover rounded-lg border-2 border-white" />
                <span className="absolute top-[-4px] right-[-3px] w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
              </div>
            </div>
            <div className="absolute bottom-2 left-16 text-white">
              <h4 className="font-bold">{artist.name}</h4>
              <p className="text-sm">{artist.username}</p>
            </div>
          </div>
        ))}
      </div>
   
    </aside>
  );
};

export default ArtistsSidebar;
