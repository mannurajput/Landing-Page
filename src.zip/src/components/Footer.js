import React from 'react';
import "./Footer.css"
const Footer = () => {
  const cards = [
    {
      id: 1,
      image: 'https://th.bing.com/th?q=Acrylic+Figure+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247',
      text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      rating: 4
    },
    {
      id: 2,
      image: 'https://th.bing.com/th/id/OIP.hv51w61Dbwd7foKmFqdljQHaH9?w=185&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"',
      text: 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      rating: 3
    },
    {
      id: 3,
      image: 'https://th.bing.com/th/id/OIP.cfTAPkZ3mdTbTxS7MQoqWQHaE8?w=282&h=188&c=7&r=0&o=5&dpr=1.3&pid=1.7',
      text: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
      rating: 5
    },
    // Add more cards as needed
  ];

  return (
    <footer className="p-4 bg-gray-100 shadow-md w-full mx-auto">
      <div className="max-w-[600px] mx-auto">
        <div className="flex overflow-x-auto hide-scroll-bar">
          {cards.map((card) => (
            <div key={card.id} className="max-w-[600px] h-[200px] rounded-lg overflow-hidden shadow-md mr-4">
              <img src={card.image} alt="Card" className="w-full h-full object-cover object-center rounded-lg" />
              <div className="p-4">
                <p className="text-gray-800 mb-2">{card.text}</p>
                <div className="flex items-center">
                  <div className="flex text-yellow-500">
                    {[...Array(card.rating)].map((_, index) => (
                      <svg key={index} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 fill-current" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 2.5a.75.75 0 0 1 .75.75v4.505l1.847 1.789a.75.75 0 1 1-1.157.962l-1.59-1.54-1.59 1.54a.75.75 0 1 1-1.157-.962L9.25 8.755V4.255a.75.75 0 0 1 .75-.75z"/>
                        <path fillRule="evenodd" d="M16.25 10a.75.75 0 0 0-.75-.75h-4.505l-1.79-1.847a.75.75 0 1 0-.962 1.157l1.54 1.59-1.54 1.59a.75.75 0 1 0 .962 1.157l1.79-1.79h4.505a.75.75 0 0 0 .75-.75z"/>
                      </svg>
                    ))}
                  </div>
                  <span className="ml-2">{card.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
