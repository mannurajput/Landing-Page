// ./src/components/Post.js
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart, faComment, faShare, faEllipsisH } from '@fortawesome/free-solid-svg-icons';

const posts = [
  {
    id: 1,
    name: 'Lara Leones',
    username: '@thewallart',
    profileImage: 'https://th.bing.com/th?q=Portrait+Art+Painting&w=120&h=120&c=1&rs=1&qlt=90&cb=1&dpr=1.3&pid=InlineBlock&mkt=en-IN&cc=IN&setlang=en&adlt=moderate&t=1&mw=247',
    text: 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
    image: 'https://th.bing.com/th/id/OIP.h86E3oz4NRhehFiZY6YGogHaFj?w=258&h=193&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    likes: '9.8k',
    comments: '8.6k',
    shares: '7.2k',
  },
  {
    id: 2,
    name: 'John Doe',
    username: '@johndoe',
    profileImage: 'https://www.bing.com/th/id/OIP.Dmdn2Lta4f4uv-XYEPAlFwHaHZ?w=182&h=182&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vehicula enim nec magna luctus, in fermentum nisi mollis.',
    image: 'https://th.bing.com/th/id/OIP.nUFIt9KFyHjID8ZTQ0lX1gHaEK?w=297&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    likes: '5.3k',
    comments: '2.1k',
    shares: '1.2k',
  },
  {
    id: 3,
    name: 'Jane Smith',
    username: '@janesmith',
    profileImage: 'https://th.bing.com/th/id/OIP.a7FYhFH1OBG4OG8sEimhPgHaE8?w=294&h=196&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    text: 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Donec vel massa quis turpis varius molestie.',
    image: 'https://th.bing.com/th/id/OIP.F-4TOJirAYXlxjLQ2th9hgHaFj?w=261&h=196&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    likes: '7.4k',
    comments: '3.5k',
    shares: '2.9k',
  },
  {
    id: 4,
    name: 'Alice Johnson',
    username: '@alicejohnson',
    profileImage: 'https://th.bing.com/th/id/OIP.lIxgfDKuswhjhtB7mk1fxAHaIs?w=168&h=196&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    text: 'Integer at velit vel orci sollicitudin efficitur ut nec dui. Sed sit amet mi vel arcu dapibus volutpat.',
    image: 'https://th.bing.com/th/id/OIP.nMWcp2akA-D6F2dysCAmewHaFm?w=259&h=196&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    likes: '8.9k',
    comments: '4.6k',
    shares: '3.7k',
  },
];

const Post = () => {
  return (
    <div className="bg-gray-100 flex flex-col  min-h-screen py-8 px-[6rem]">
      {posts.map((post) => (
        <div key={post.id} className="w-full px-10">
          <div className="bg-white w-[620px] h-[600px] rounded-lg shadow-md mb-4 mx-auto">
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center">
                <img
                  className="w-12 h-12 rounded-l-lg rounded-r-[10px]"
                  src={post.profileImage}
                  alt="profile"
                />
                <div className="ml-4">
                  <h2 className="font-bold">{post.name}</h2>
                  <p className="text-gray-500">{post.username}</p>
                </div>
              </div>
              <FontAwesomeIcon icon={faEllipsisH} className="text-gray-500" />
            </div>
            <p className="px-4">{post.text} <span className="text-blue-500">Read More</span></p>
            <div className="px-4 mt-4 relative flex justify-center">
              <img
                className="w-[560px] h-[306px] rounded-lg object-cover"
                src={post.image}
                alt="wall art"
              />
              <div className="absolute top-5 right-12 text-white">
                <FontAwesomeIcon icon={faHeart} className="text-pink-500 text-xl" />
              </div>
            </div>
<hr className='mt-14'></hr>
            <div className="flex justify-between items-center w-[300px] px-8 mt-8 pb-4">
              <div className="text-pink-500">
                <FontAwesomeIcon icon={faHeart} className="mr-1" /> {post.likes}
              </div>
              <div className="text-gray-500">
                <FontAwesomeIcon icon={faComment} className="mr-1" /> {post.comments}
              </div>
              <div className="text-gray-500">
                <FontAwesomeIcon icon={faShare} className="mr-1" /> {post.shares}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Post;
